MantisBT-PastePicture
=====================

Paste print screens directly into MatisBT issue reporting(details) page