hx.ready(function() {
    // code to run when the DOM is ready
  });
