"""
group_by.py

This module is used to make queryset by groups
"""
